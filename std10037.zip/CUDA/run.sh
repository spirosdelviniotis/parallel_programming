#!bin/bash
cd ~/.netbeans/remote/195.134.67.205/delvinio-Windows-x86_64/C/Users/Spiros\ Delviniotis/Documents/NetBeansProjects/Parallel_programming_DI/parallel_programming_DI/CUDA
./CUDA_main
